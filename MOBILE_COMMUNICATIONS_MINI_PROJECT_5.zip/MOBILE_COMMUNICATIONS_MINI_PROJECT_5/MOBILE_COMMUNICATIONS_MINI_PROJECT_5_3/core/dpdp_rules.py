
def check_dpdp(practice):
    results = []

    # Rule 1: Clear notice must be provided.
    if practice["clear_notice"]:
        results.append(("DPDP-01", "COMPLIANT",
                        "Clear notice is provided to the Data Principal."))
    else:
        results.append(("DPDP-01", "GAP",
                        "Clear notice is missing."))

    # Rule 2: Consent or applicable legitimate use.
    if practice["lawful_basis"] in ["consent", "legitimate_use"]:
        results.append(("DPDP-02", "COMPLIANT",
                        "Consent or a declared legitimate use exists."))
    else:
        results.append(("DPDP-02", "GAP",
                        "No valid consent or applicable legitimate use is declared."))

    # Rule 3: Consent must be affirmative when required.
    if practice["lawful_basis"] == "consent":
        if practice["consent_mechanism"] == "opt-in":
            results.append(("DPDP-03", "COMPLIANT",
                            "Affirmative consent is used."))
        else:
            results.append(("DPDP-03", "GAP",
                            "Consent is not obtained through an affirmative opt-in."))
    else:
        results.append(("DPDP-03", "N/A",
                        "Consent is not the declared processing basis."))

    # Rule 4: Third-party processing must be disclosed.
    if practice["third_party_sharing"]:
        if practice["sharing_disclosed"]:
            results.append(("DPDP-04", "COMPLIANT",
                            "Third-party processing is disclosed."))
        else:
            results.append(("DPDP-04", "GAP",
                            "Third-party processing is not disclosed."))
    else:
        results.append(("DPDP-04", "N/A",
                        "No third-party sharing is declared."))

    # Rule 5: Retention and deletion policy.
    if practice["retention_months"] > 0 and practice["deletion_policy"]:
        results.append(("DPDP-05", "COMPLIANT",
                        "Retention and deletion policy are declared."))
    else:
        results.append(("DPDP-05", "GAP",
                        "Retention or deletion policy is missing."))

    return results
