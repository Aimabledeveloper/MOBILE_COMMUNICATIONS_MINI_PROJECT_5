
def check_lgpd(practice):
    results = []

    # Rule 1: Valid legal basis.
    if practice["lawful_basis"]:
        results.append(("LGPD-01", "COMPLIANT",
                        "A legal basis is declared."))
    else:
        results.append(("LGPD-01", "GAP",
                        "No legal basis is declared."))

    # Rule 2: Affirmative consent when consent is the basis.
    if practice["lawful_basis"] == "consent":
        if practice["consent_mechanism"] == "opt-in":
            results.append(("LGPD-02", "COMPLIANT",
                            "Affirmative consent is used."))
        else:
            results.append(("LGPD-02", "GAP",
                            "Consent-based processing lacks affirmative consent."))
    else:
        results.append(("LGPD-02", "N/A",
                        "Consent is not the selected legal basis."))

    # Rule 3: Sensitive data requires an appropriate legal condition.
    if practice["category"] == "biometric":
        if practice["special_category_condition"]:
            results.append(("LGPD-03", "COMPLIANT",
                            "A sensitive-data processing condition is declared."))
        else:
            results.append(("LGPD-03", "GAP",
                            "No appropriate sensitive-data condition is declared."))
    else:
        results.append(("LGPD-03", "N/A",
                        "The data is not marked sensitive."))

    # Rule 4: Sharing transparency.
    if practice["third_party_sharing"]:
        if practice["sharing_disclosed"]:
            results.append(("LGPD-04", "COMPLIANT",
                            "Third-party sharing is disclosed."))
        else:
            results.append(("LGPD-04", "GAP",
                            "Third-party sharing is not disclosed."))
    else:
        results.append(("LGPD-04", "N/A",
                        "No third-party sharing is declared."))

    # Rule 5: Retention period.
    if practice["retention_months"] > 0:
        results.append(("LGPD-05", "COMPLIANT",
                        "A retention period is defined."))
    else:
        results.append(("LGPD-05", "GAP",
                        "No valid retention period is defined."))

    return results
