
def check_ccpa(practice):
    results = []

    # Rule 1: Collection must be disclosed.
    if practice["collection_disclosed"]:
        results.append(("CCPA-01", "COMPLIANT",
                        "Data collection is disclosed."))
    else:
        results.append(("CCPA-01", "GAP",
                        "Data collection is not disclosed."))

    # Rule 2: Sale or sharing requires an appropriate opt-out mechanism.
    if practice["sale_or_sharing"]:
        if practice["opt_out_available"]:
            results.append(("CCPA-02", "COMPLIANT",
                            "An opt-out mechanism is available."))
        else:
            results.append(("CCPA-02", "GAP",
                            "No opt-out mechanism is available."))
    else:
        results.append(("CCPA-02", "N/A",
                        "No sale or sharing is declared."))

    # Rule 3: Sensitive personal information must be identified.
    if practice["sensitive_personal_information"]:
        if practice["sensitive_use_controls"]:
            results.append(("CCPA-03", "COMPLIANT",
                            "Sensitive information use controls are declared."))
        else:
            results.append(("CCPA-03", "GAP",
                            "Sensitive information use controls are missing."))
    else:
        results.append(("CCPA-03", "N/A",
                        "The data is not marked sensitive."))

    # Rule 4: Third-party sharing must be disclosed.
    if practice["third_party_sharing"]:
        if practice["sharing_disclosed"]:
            results.append(("CCPA-04", "COMPLIANT",
                            "Third-party sharing is disclosed."))
        else:
            results.append(("CCPA-04", "GAP",
                            "Third-party sharing is not disclosed."))
    else:
        results.append(("CCPA-04", "N/A",
                        "No third-party sharing is declared."))

    # Rule 5: Retention must be disclosed.
    if practice["retention_disclosed"]:
        results.append(("CCPA-05", "COMPLIANT",
                        "Retention period is disclosed."))
    else:
        results.append(("CCPA-05", "GAP",
                        "Retention period is not disclosed."))

    return results
