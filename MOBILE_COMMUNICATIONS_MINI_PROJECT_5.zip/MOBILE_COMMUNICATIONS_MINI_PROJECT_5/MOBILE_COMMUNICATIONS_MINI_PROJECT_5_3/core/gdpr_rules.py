
def check_gdpr(practice):
    results = []

    # Rule 1: A documented lawful basis must exist.
    if practice["lawful_basis"]:
        results.append(("GDPR-01", "COMPLIANT",
                        "A lawful basis is declared."))
    else:
        results.append(("GDPR-01", "GAP",
                        "No lawful basis is declared."))

    # Rule 2: Consent must be affirmative when consent is the basis.
    if practice["lawful_basis"] == "consent":
        if practice["consent_mechanism"] == "opt-in":
            results.append(("GDPR-02", "COMPLIANT",
                            "Affirmative opt-in consent is used."))
        else:
            results.append(("GDPR-02", "GAP",
                            "Consent-based processing lacks affirmative opt-in."))
    else:
        results.append(("GDPR-02", "N/A",
                        "Consent is not the selected lawful basis."))

    # Rule 3: Special-category data requires additional conditions.
    if practice["category"] in ["biometric", "health"]:
        if practice["special_category_condition"]:
            results.append(("GDPR-03", "COMPLIANT",
                            "An additional special-category condition is declared."))
        else:
            results.append(("GDPR-03", "GAP",
                            "No additional special-category condition is declared."))
    else:
        results.append(("GDPR-03", "N/A",
                        "This data is not classified as special-category data."))

    # Rule 4: Third-party sharing must be disclosed.
    if practice["third_party_sharing"]:
        if practice["sharing_disclosed"]:
            results.append(("GDPR-04", "COMPLIANT",
                            "Third-party sharing is disclosed."))
        else:
            results.append(("GDPR-04", "GAP",
                            "Third-party sharing is not disclosed."))
    else:
        results.append(("GDPR-04", "N/A",
                        "No third-party sharing is declared."))

    # Rule 5: Retention must be defined.
    if practice["retention_months"] > 0:
        results.append(("GDPR-05", "COMPLIANT",
                        "A retention period is defined."))
    else:
        results.append(("GDPR-05", "GAP",
                        "No valid retention period is defined."))

    return results
