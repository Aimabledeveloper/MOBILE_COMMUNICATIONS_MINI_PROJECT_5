
"""
FitTrack Mobile - Automatic Privacy Remediation Engine.

Reads actual compliance results and generates corrective
recommendations for GDPR, CCPA/CPRA, LGPD and DPDP Act.
"""

from pathlib import Path

from core.app_data import APP_NAME, APP_DATA
from core.compliance_engine import FRAMEWORKS, evaluate_practice


# Recommendations for each compliance rule.
REMEDIATION_RULES = {
    "GDPR-01": (
        "HIGH",
        "Document and verify the appropriate GDPR lawful basis "
        "for each processing activity."
    ),
    "GDPR-02": (
        "HIGH",
        "Implement clear, specific and affirmative opt-in consent "
        "where consent is the selected lawful basis. Allow users "
        "to withdraw consent easily."
    ),
    "GDPR-03": (
        "HIGH",
        "Identify and document an applicable Article 9 condition "
        "for processing special-category biometric data. "
        "Apply appropriate additional safeguards."
    ),
    "GDPR-04": (
        "MEDIUM",
        "Update the privacy notice to identify third-party "
        "recipients, sharing purposes and relevant safeguards."
    ),
    "GDPR-05": (
        "MEDIUM",
        "Establish a documented retention schedule and securely "
        "delete or anonymize personal data when no longer needed."
    ),

    "CCPA-01": (
        "HIGH",
        "Clearly disclose the categories of personal information "
        "collected and the purposes of collection."
    ),
    "CCPA-02": (
        "HIGH",
        "Provide applicable mechanisms for consumers to opt out "
        "of the sale or sharing of personal information."
    ),
    "CCPA-03": (
        "HIGH",
        "Provide applicable sensitive personal information "
        "limitation rights and controls, including clear "
        "disclosures and mechanisms required by the CPRA."
    ),
    "CCPA-04": (
        "MEDIUM",
        "Disclose relevant third-party sharing practices and "
        "ensure applicable service-provider and contractor "
        "contractual requirements are satisfied."
    ),
    "CCPA-05": (
        "MEDIUM",
        "Disclose retention periods or criteria for each category "
        "of personal information and avoid excessive retention."
    ),

    "LGPD-01": (
        "HIGH",
        "Identify and document an appropriate LGPD legal basis "
        "for each personal-data processing activity."
    ),
    "LGPD-02": (
        "HIGH",
        "Obtain free, informed and unambiguous consent when "
        "consent is the selected legal basis."
    ),
    "LGPD-03": (
        "HIGH",
        "Document an applicable LGPD legal hypothesis for "
        "sensitive personal data, such as biometric information, "
        "and apply appropriate safeguards."
    ),
    "LGPD-04": (
        "MEDIUM",
        "Disclose relevant data-sharing arrangements and verify "
        "that third-party processing and transfers comply with "
        "applicable LGPD requirements."
    ),
    "LGPD-05": (
        "MEDIUM",
        "Define data-retention periods and procedures for "
        "secure deletion or anonymization when appropriate."
    ),

    "DPDP-01": (
        "HIGH",
        "Provide a clear notice to the Data Principal describing "
        "the personal data collected, its purposes and the "
        "required information about consent."
    ),
    "DPDP-02": (
        "HIGH",
        "Identify and document a valid consent basis or an "
        "applicable legitimate use under the DPDP Act."
    ),
    "DPDP-03": (
        "HIGH",
        "Implement valid, free, specific, informed, unconditional "
        "and unambiguous consent through clear affirmative action "
        "where consent is required."
    ),
    "DPDP-04": (
        "MEDIUM",
        "Clearly explain relevant third-party processing "
        "arrangements and establish appropriate processor "
        "contracts and safeguards."
    ),
    "DPDP-05": (
        "MEDIUM",
        "Establish retention and erasure procedures, including "
        "deletion when the specified purpose is no longer served "
        "unless retention is legally required."
    ),
}


def get_recommendation(rule_id, practice):
    """Return the priority and recommendation for a compliance gap."""

    priority, recommendation = REMEDIATION_RULES.get(
        rule_id,
        (
            "MEDIUM",
            "Review the applicable privacy requirement and "
            "implement corrective controls."
        )
    )

    # Give sensitive-data gaps additional attention.
    if practice["category"] in ("location", "biometric"):
        priority = "HIGH"

    return priority, recommendation


def analyze_remediations():
    """Collect every GAP and its corresponding recommendation."""

    remediations = []

    for practice in APP_DATA:

        evaluation = evaluate_practice(practice)

        for framework, results in evaluation.items():

            for rule_id, status, reason in results:

                if status != "GAP":
                    continue

                priority, recommendation = get_recommendation(
                    rule_id,
                    practice
                )

                remediations.append({
                    "practice_id": practice["id"],
                    "practice_name": practice["name"],
                    "category": practice["category"],
                    "framework": framework,
                    "rule_id": rule_id,
                    "reason": reason,
                    "priority": priority,
                    "recommendation": recommendation,
                })

    return remediations


def generate_remediation_report():
    """Generate a complete automatic remediation report."""

    remediations = analyze_remediations()

    priorities = {
        "HIGH": 0,
        "MEDIUM": 0,
        "LOW": 0,
    }

    framework_counts = {
        framework: 0
        for framework in FRAMEWORKS
    }

    for item in remediations:
        priorities[item["priority"]] += 1
        framework_counts[item["framework"]] += 1

    report = []

    report.append("=" * 90)
    report.append(f"{APP_NAME} - PRIVACY REMEDIATION REPORT")
    report.append("=" * 90)

    report.append("")
    report.append("REPORT OVERVIEW")
    report.append("-" * 90)
    report.append(f"Application: {APP_NAME}")
    report.append(f"Data practices analyzed: {len(APP_DATA)}")
    report.append(f"Frameworks evaluated: {len(FRAMEWORKS)}")
    report.append(f"Total identified gaps: {len(remediations)}")

    report.append("")
    report.append("PRIORITY SUMMARY")
    report.append("-" * 90)

    for priority, count in priorities.items():
        report.append(f"{priority}: {count}")

    report.append("")
    report.append("GAPS BY FRAMEWORK")
    report.append("-" * 90)

    for framework, count in framework_counts.items():
        report.append(f"{framework}: {count}")

    report.append("")
    report.append("=" * 90)
    report.append("DETAILED REMEDIATION ACTIONS")
    report.append("=" * 90)

    for index, item in enumerate(remediations, start=1):

        report.append("")
        report.append("-" * 90)
        report.append(f"REMEDIATION #{index}")
        report.append("-" * 90)

        report.append(
            f"Data practice: {item['practice_name']}"
        )
        report.append(
            f"Framework: {item['framework']}"
        )
        report.append(
            f"Rule ID: {item['rule_id']}"
        )
        report.append(
            f"Priority: {item['priority']}"
        )
        report.append(
            f"Identified issue: {item['reason']}"
        )
        report.append(
            f"Recommended action: {item['recommendation']}"
        )

    report.append("")
    report.append("=" * 90)
    report.append("FINAL REMEDIATION SUMMARY")
    report.append("=" * 90)

    report.append(
        f"Total gaps requiring attention: {len(remediations)}"
    )
    report.append(
        f"High-priority actions: {priorities['HIGH']}"
    )
    report.append(
        f"Medium-priority actions: {priorities['MEDIUM']}"
    )
    report.append(
        f"Low-priority actions: {priorities['LOW']}"
    )

    report.append("")
    report.append(
        "Recommended approach: Address high-priority gaps first, "
        "especially those involving location and biometric data."
    )

    report.append("")
    report.append(
        "Note: This report is an educational compliance screening "
        "tool, not a substitute for professional legal advice."
    )

    report.append("=" * 90)

    return "\n".join(report)


def main():
    """Generate, display and save the remediation report."""

    output_directory = Path("outputs")
    output_directory.mkdir(exist_ok=True)

    report = generate_remediation_report()

    print(report)

    output_file = output_directory / "remediation_report.txt"

    output_file.write_text(report, encoding="utf-8")

    print("\nRemediation report successfully saved to:")
    print(output_file.resolve())


if __name__ == "__main__":
    main()
