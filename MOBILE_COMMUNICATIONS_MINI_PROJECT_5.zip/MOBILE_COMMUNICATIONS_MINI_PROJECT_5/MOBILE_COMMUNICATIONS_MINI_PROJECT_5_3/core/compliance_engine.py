
"""
FitTrack Mobile Privacy Compliance Checklist Engine.

Evaluates declared data practices against:
- GDPR
- CCPA/CPRA
- LGPD
- DPDP Act
"""

from pathlib import Path

from core.app_data import APP_NAME, APP_DATA
from core.gdpr_rules import check_gdpr
from core.ccpa_rules import check_ccpa
from core.lgpd_rules import check_lgpd
from core.dpdp_rules import check_dpdp


FRAMEWORKS = {
    "GDPR": check_gdpr,
    "CCPA/CPRA": check_ccpa,
    "LGPD": check_lgpd,
    "DPDP ACT": check_dpdp,
}


def evaluate_practice(practice):
    """Evaluate one data practice against all frameworks."""

    evaluation = {}

    for framework, rule_function in FRAMEWORKS.items():
        evaluation[framework] = rule_function(practice)

    return evaluation


def generate_gap_report():
    """Generate a complete compliance gap analysis."""

    report = []

    report.append("=" * 85)
    report.append(f"{APP_NAME} - PRIVACY COMPLIANCE GAP ANALYSIS")
    report.append("=" * 85)

    statistics = {
        framework: {
            "COMPLIANT": 0,
            "GAP": 0,
            "N/A": 0,
        }
        for framework in FRAMEWORKS
    }

    total_gaps = 0

    for practice in APP_DATA:

        report.append("")
        report.append("-" * 85)
        report.append(
            f"DATA PRACTICE #{practice['id']}: {practice['name']}"
        )
        report.append("-" * 85)

        report.append(f"Purpose: {practice['purpose']}")
        report.append(
            f"Consent mechanism: {practice['consent_mechanism']}"
        )
        report.append(
            f"Retention: {practice['retention_months']} months"
        )

        evaluation = evaluate_practice(practice)

        for framework, results in evaluation.items():

            report.append("")
            report.append(f"[{framework}]")

            for rule_id, status, reason in results:

                statistics[framework][status] += 1

                if status == "GAP":
                    total_gaps += 1

                report.append(
                    f"{rule_id} | {status} | {reason}"
                )

    report.append("")
    report.append("=" * 85)
    report.append("COMPLIANCE SUMMARY")
    report.append("=" * 85)

    for framework, counts in statistics.items():

        report.append("")
        report.append(framework)

        report.append(f"  Compliant: {counts['COMPLIANT']}")
        report.append(f"  Gaps:      {counts['GAP']}")
        report.append(f"  N/A:       {counts['N/A']}")

        applicable = counts["COMPLIANT"] + counts["GAP"]

        percentage = (
            counts["COMPLIANT"] / applicable * 100
            if applicable else 0
        )

        report.append(
            f"  Screening score: {percentage:.2f}%"
        )

    report.append("")
    report.append("=" * 85)
    report.append(f"TOTAL IDENTIFIED GAPS: {total_gaps}")
    report.append("=" * 85)

    return "\n".join(report)


def main():
    """Run the checklist and save the output."""

    output_directory = Path("outputs")
    output_directory.mkdir(exist_ok=True)

    report = generate_gap_report()

    print(report)

    output_file = output_directory / "gap_analysis_output.txt"

    output_file.write_text(report, encoding="utf-8")

    print("\nReport successfully saved to:")
    print(output_file.resolve())


if __name__ == "__main__":
    main()
