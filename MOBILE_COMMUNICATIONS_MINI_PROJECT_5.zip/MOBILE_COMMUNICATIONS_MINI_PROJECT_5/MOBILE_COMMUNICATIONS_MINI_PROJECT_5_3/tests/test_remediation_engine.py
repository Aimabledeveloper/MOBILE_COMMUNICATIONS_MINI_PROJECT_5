
import unittest

from core.remediation_engine import (
    analyze_remediations,
    generate_remediation_report,
)


class TestRemediationEngine(unittest.TestCase):

    def setUp(self):
        self.remediations = analyze_remediations()

    def test_all_gaps_are_collected(self):
        self.assertEqual(len(self.remediations), 30)

    def test_every_remediation_has_required_fields(self):
        required_fields = {
            "practice_id",
            "practice_name",
            "category",
            "framework",
            "rule_id",
            "reason",
            "priority",
            "recommendation",
        }

        for item in self.remediations:
            self.assertTrue(
                required_fields.issubset(item.keys())
            )

    def test_only_valid_priorities_are_used(self):
        valid_priorities = {"HIGH", "MEDIUM", "LOW"}

        for item in self.remediations:
            self.assertIn(item["priority"], valid_priorities)

    def test_all_four_frameworks_are_represented(self):
        frameworks = {
            item["framework"]
            for item in self.remediations
        }

        self.assertEqual(
            frameworks,
            {"GDPR", "CCPA/CPRA", "LGPD", "DPDP ACT"}
        )

    def test_sensitive_data_gaps_are_high_priority(self):
        for item in self.remediations:
            if item["category"] in ("location", "biometric"):
                self.assertEqual(item["priority"], "HIGH")

    def test_no_compliant_results_are_included(self):
        for item in self.remediations:
            self.assertTrue(item["rule_id"])
            self.assertTrue(item["recommendation"])

    def test_report_contains_remediation_sections(self):
        report = generate_remediation_report()

        self.assertIn("PRIORITY SUMMARY", report)
        self.assertIn("DETAILED REMEDIATION ACTIONS", report)
        self.assertIn("FINAL REMEDIATION SUMMARY", report)
        self.assertIn("Total identified gaps: 30", report)

    def test_report_contains_all_frameworks(self):
        report = generate_remediation_report()

        for framework in ("GDPR", "CCPA/CPRA", "LGPD", "DPDP ACT"):
            self.assertIn(framework, report)


if __name__ == "__main__":
    unittest.main()
