
import unittest

from core.app_data import APP_DATA
from core.compliance_engine import (
    FRAMEWORKS,
    evaluate_practice,
    generate_gap_report,
)


class TestPrivacyComplianceEngine(unittest.TestCase):

    def test_six_data_practices_exist(self):
        """The application must contain six sample practices."""

        self.assertEqual(len(APP_DATA), 6)

    def test_four_frameworks_exist(self):
        """All four privacy frameworks must be evaluated."""

        self.assertEqual(len(FRAMEWORKS), 4)

        self.assertIn("GDPR", FRAMEWORKS)
        self.assertIn("CCPA/CPRA", FRAMEWORKS)
        self.assertIn("LGPD", FRAMEWORKS)
        self.assertIn("DPDP ACT", FRAMEWORKS)

    def test_each_practice_has_four_framework_results(self):
        """Every practice must be evaluated against all frameworks."""

        for practice in APP_DATA:
            results = evaluate_practice(practice)

            self.assertEqual(len(results), 4)

    def test_each_framework_has_five_rules(self):
        """Each framework must return five checklist results."""

        for practice in APP_DATA:
            results = evaluate_practice(practice)

            for framework, rules in results.items():
                self.assertEqual(
                    len(rules), 5,
                    f"{framework} should have five rules."
                )

    def test_only_valid_statuses_are_returned(self):
        """Results must use COMPLIANT, GAP or N/A."""

        valid_statuses = {"COMPLIANT", "GAP", "N/A"}

        for practice in APP_DATA:
            results = evaluate_practice(practice)

            for rules in results.values():
                for rule_id, status, reason in rules:
                    self.assertIn(status, valid_statuses)
                    self.assertTrue(rule_id)
                    self.assertTrue(reason)

    def test_gdpr_detects_location_consent_gap(self):
        """Bundled GPS consent should be flagged."""

        gps = APP_DATA[1]
        results = evaluate_practice(gps)

        statuses = {
            rule_id: status
            for rule_id, status, reason in results["GDPR"]
        }

        self.assertEqual(statuses["GDPR-02"], "GAP")

    def test_ccpa_detects_missing_sensitive_data_controls(self):
        """GPS sensitive information controls should be flagged."""

        gps = APP_DATA[1]
        results = evaluate_practice(gps)

        statuses = {
            rule_id: status
            for rule_id, status, reason in results["CCPA/CPRA"]
        }

        self.assertEqual(statuses["CCPA-03"], "GAP")

    def test_valid_opt_in_is_accepted(self):
        """Contact information uses affirmative opt-in."""

        contacts = APP_DATA[2]
        results = evaluate_practice(contacts)

        statuses = {
            rule_id: status
            for rule_id, status, reason in results["GDPR"]
        }

        self.assertEqual(statuses["GDPR-02"], "COMPLIANT")

    def test_biometric_data_gap_is_detected(self):
        """Missing biometric processing condition must be flagged."""

        biometric = APP_DATA[5]
        results = evaluate_practice(biometric)

        statuses = {
            rule_id: status
            for rule_id, status, reason in results["GDPR"]
        }

        self.assertEqual(statuses["GDPR-03"], "GAP")
        self.assertEqual(statuses["GDPR-05"], "GAP")

    def test_advertising_opt_out_is_accepted(self):
        """Advertising sharing has an opt-out setting."""

        advertising = APP_DATA[4]
        results = evaluate_practice(advertising)

        statuses = {
            rule_id: status
            for rule_id, status, reason in results["CCPA/CPRA"]
        }

        self.assertEqual(statuses["CCPA-02"], "COMPLIANT")

    def test_usage_analytics_notice_gap(self):
        """Missing DPDP notice must be flagged."""

        analytics = APP_DATA[3]
        results = evaluate_practice(analytics)

        statuses = {
            rule_id: status
            for rule_id, status, reason in results["DPDP ACT"]
        }

        self.assertEqual(statuses["DPDP-01"], "GAP")

    def test_gap_report_contains_all_frameworks(self):
        """Generated report must contain all four frameworks."""

        report = generate_gap_report()

        for framework in FRAMEWORKS:
            self.assertIn(framework, report)

    def test_gap_report_contains_total_gaps(self):
        """The current sample should identify 31 gaps."""

        report = generate_gap_report()

        self.assertIn("TOTAL IDENTIFIED GAPS: 30", report)

    def test_gap_report_contains_all_data_practices(self):
        """All six practices must appear in the report."""

        report = generate_gap_report()

        for practice in APP_DATA:
            self.assertIn(practice["name"], report)


if __name__ == "__main__":
    unittest.main(verbosity=2)
