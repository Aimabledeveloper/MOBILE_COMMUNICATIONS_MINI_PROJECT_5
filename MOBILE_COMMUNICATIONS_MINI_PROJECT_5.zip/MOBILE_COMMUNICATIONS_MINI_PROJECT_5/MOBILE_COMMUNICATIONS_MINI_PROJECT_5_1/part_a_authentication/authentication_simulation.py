
import hashlib
import hmac
import secrets


# ============================================================
# 1. CRYPTOGRAPHIC FUNCTIONS
# ============================================================

def generate_rand():
    """
    Generate a fresh random authentication challenge.
    Minimum length: 16 bytes.
    """
    return secrets.token_bytes(16)


def compute_response(key, rand):
    """
    Calculate the device authentication response
    using HMAC-SHA256.
    """
    return hmac.new(
        key,
        rand,
        hashlib.sha256
    ).digest()


def derive_session_key(key, rand):
    """
    Derive a session key using a distinct label.
    This ensures the session key differs from the response.
    """
    return hmac.new(
        key,
        b"SESSIONKEY" + rand,
        hashlib.sha256
    ).digest()


def compute_network_token(key, rand):
    """
    Generate a network authentication token.
    This allows the device to verify the home network.
    """
    return hmac.new(
        key,
        b"NETWORK_AUTH" + rand,
        hashlib.sha256
    ).digest()


# ============================================================
# 2. MOBILE DEVICE
# ============================================================

class Device:

    def __init__(self, secret_key):
        self.secret_key = secret_key

    def authenticate(self, rand):
        """
        Calculate the response to the network challenge.
        """
        return compute_response(self.secret_key, rand)

    def derive_session_key(self, rand):
        return derive_session_key(self.secret_key, rand)

    def verify_network(self, rand, network_token):
        """
        Verify that the home network knows the shared secret.
        """
        expected_token = compute_network_token(
            self.secret_key,
            rand
        )

        return hmac.compare_digest(
            expected_token,
            network_token
        )


# ============================================================
# 3. HOME NETWORK
# ============================================================

class HomeNetwork:

    def __init__(self, secret_key):
        self.secret_key = secret_key
        self.used_rands = set()

    def generate_challenge(self):
        """
        Generate a unique random challenge.
        """
        rand = generate_rand()

        while rand in self.used_rands:
            rand = generate_rand()

        return rand

    def verify_device(self, rand, device_response):
        """
        Verify the device response and reject reused challenges.
        """
        if rand in self.used_rands:
            print("REPLAY DETECTED: Challenge already used.")
            return False

        self.used_rands.add(rand)

        expected_response = compute_response(
            self.secret_key,
            rand
        )

        return hmac.compare_digest(
            expected_response,
            device_response
        )

    def authenticate_network(self, rand):
        """
        Generate a token proving network knowledge of the key.
        """
        return compute_network_token(
            self.secret_key,
            rand
        )

    def derive_session_key(self, rand):
        return derive_session_key(self.secret_key, rand)


# ============================================================
# 4. ATTACKER SIMULATION
# ============================================================

class Attacker:

    def __init__(self):
        # The attacker does not possess the shared secret.
        self.captured_rand = None
        self.captured_response = None

    def intercept(self, rand, response):
        """
        Capture information transmitted over the channel.
        """
        self.captured_rand = rand
        self.captured_response = response

    def replay_response(self):
        """
        Attempt to reuse an old response for a new challenge.
        """
        return self.captured_response


# ============================================================
# 5. MAIN AUTHENTICATION EXPERIMENT
# ============================================================

def main():

    print("=" * 65)
    print("CELLULAR-STYLE MUTUAL AUTHENTICATION SIMULATION")
    print("=" * 65)

    # Generate a shared secret.
    # In a real system, the key would be securely provisioned.
    shared_secret = secrets.token_bytes(32)

    device = Device(shared_secret)
    network = HomeNetwork(shared_secret)

    attacker = Attacker()

    # --------------------------------------------------------
    # EXPERIMENT 1: LEGITIMATE AUTHENTICATION
    # --------------------------------------------------------

    print("\n[EXPERIMENT 1] LEGITIMATE AUTHENTICATION")

    rand1 = network.generate_challenge()

    print("Network generated a fresh challenge.")
    print("RAND length:", len(rand1), "bytes")

    # Device calculates its response.
    device_response = device.authenticate(rand1)

    # Attacker observes only transmitted values.
    attacker.intercept(rand1, device_response)

    # Home network independently verifies the response.
    authenticated = network.verify_device(
        rand1,
        device_response
    )

    print("Device response verified:", authenticated)

    # Both parties independently derive a session key.
    device_key = device.derive_session_key(rand1)
    network_key = network.derive_session_key(rand1)

    session_keys_match = hmac.compare_digest(
        device_key,
        network_key
    )

    print("Device and network session keys match:",
          session_keys_match)

    # Network proves its identity to the device.
    network_token = network.authenticate_network(rand1)

    network_verified = device.verify_network(
        rand1,
        network_token
    )

    print("Home network successfully authenticated:",
          network_verified)

    # --------------------------------------------------------
    # EXPERIMENT 2: REPLAY / FORGERY ATTACK
    # --------------------------------------------------------

    print("\n[EXPERIMENT 2] ATTACKER REPLAY ATTEMPT")

    # Generate a completely new challenge.
    rand2 = network.generate_challenge()

    print("Network generated a new challenge.")

    # Attacker attempts to reuse the previously captured response.
    forged_response = attacker.replay_response()

    # Network calculates the correct response for RAND2.
    expected_response = compute_response(
        shared_secret,
        rand2
    )

    # Compare the attacker's response with the expected response.
    forgery_successful = hmac.compare_digest(
        forged_response,
        expected_response
    )

    print("Attacker possesses shared secret: False")
    print("Attacker reused an old response.")
    print("Forged response accepted:", forgery_successful)

    # --------------------------------------------------------
    # EXPERIMENT 3: CHALLENGE REPLAY PROTECTION
    # --------------------------------------------------------

    print("\n[EXPERIMENT 3] USED CHALLENGE REJECTION")

    reused_challenge_result = network.verify_device(
        rand1,
        device_response
    )

    print("Previously used challenge accepted:",
          reused_challenge_result)

    # --------------------------------------------------------
    # FINAL SECURITY SUMMARY
    # --------------------------------------------------------

    print("\n" + "=" * 65)
    print("AUTHENTICATION SIMULATION SUMMARY")
    print("=" * 65)

    print("Legitimate device authentication:", authenticated)
    print("Session keys match:", session_keys_match)
    print("Network authentication:", network_verified)
    print("Attacker forged a new response:", forgery_successful)
    print("Reused challenge accepted:", reused_challenge_result)

    print("\nShared secret and session key values were never")
    print("transmitted through the simulated communication channel.")

    print("\nSIMULATION COMPLETED.")


if __name__ == "__main__":
    main()
