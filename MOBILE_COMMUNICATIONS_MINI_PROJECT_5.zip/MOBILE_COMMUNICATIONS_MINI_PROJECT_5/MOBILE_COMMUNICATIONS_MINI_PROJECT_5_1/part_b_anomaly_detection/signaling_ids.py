
import random
from datetime import datetime, timedelta
from collections import defaultdict


# ============================================================
# 1. CONFIGURATION
# ============================================================

ALLOWED_EVENT_TYPES = {
    "attach",
    "location_update",
    "auth_request"
}

# Default minimum travel time for country changes.
MIN_TRAVEL_TIME_HOURS = 3

# Country-pair-specific minimum travel times (hours).
# These are illustrative values for this simulation.
MIN_TRAVEL_TIME_BY_ROUTE = {
    ("Rwanda", "Uganda"): 0.5,
    ("Uganda", "Rwanda"): 0.5,

    ("Rwanda", "United Kingdom"): 6,
    ("United Kingdom", "Rwanda"): 6
}

AUTH_WINDOW_MINUTES = 5
MAX_AUTH_REQUESTS = 3
ATTACH_WINDOW_MINUTES = 1
MAX_ATTACH_REQUESTS = 5

# ============================================================
# 2. GENERATE SYNTHETIC SIGNALING LOG
# ============================================================


def generate_signaling_log(n=20):

    events = []

    subscriber_countries = {
        "SUB001": "Rwanda",
        "SUB002": "Kenya",
        "SUB003": "Uganda",
        "SUB004": "Tanzania",
        "SUB005": "Rwanda"
    }

    subscribers = list(subscriber_countries.keys())

    event_types = [
        "attach",
        "location_update",
        "auth_request"
    ]

    base_time = datetime(2026, 11, 21, 8, 0, 0)

    for i in range(n):

        subscriber = random.choice(subscribers)

        event = {
            "timestamp": (
                base_time + timedelta(minutes=i * 15)
            ).isoformat(),

            "subscriber_id": subscriber,

            "event_type": random.choice(event_types),

            "country": subscriber_countries[subscriber]
        }

        events.append(event)

    return events



# ============================================================
# 3. INJECT CONTROLLED ANOMALIES
# ============================================================

def inject_anomalies(events):

    base_time = datetime(2026, 11, 21, 12, 0, 0)

    # Anomaly 1: Implausible international travel

    events.append({
        "timestamp": base_time.isoformat(),
        "subscriber_id": "SUB_TRAVEL",
        "event_type": "location_update",
        "country": "Rwanda"
    })

    events.append({
        "timestamp": (
            base_time + timedelta(minutes=20)
        ).isoformat(),

        "subscriber_id": "SUB_TRAVEL",
        "event_type": "location_update",
        "country": "United Kingdom"
    })

    # Anomaly 2: Malformed message (missing country)

    events.append({
        "timestamp": (
            base_time + timedelta(hours=1)
        ).isoformat(),

        "subscriber_id": "SUB_MALFORMED",
        "event_type": "attach"
        # country field deliberately missing
    })

    # Anomaly 3: Invalid event type

    events.append({
        "timestamp": (
            base_time + timedelta(hours=2)
        ).isoformat(),

        "subscriber_id": "SUB_INVALID",
        "event_type": "unknown_event",
        "country": "Rwanda"
    })

    # Anomaly 4: Authentication request burst

    for i in range(6):

        events.append({
            "timestamp": (
                base_time + timedelta(hours=3, seconds=i * 30)
            ).isoformat(),

            "subscriber_id": "SUB_BURST",
            "event_type": "auth_request",
            "country": "Rwanda"
        })

        # Anomaly 5: Non-monotonic timestamps

    events.append({
        "timestamp": "2026-11-21T16:10:00",
        "subscriber_id": "SUB_ORDER",
        "event_type": "location_update",
        "country": "Rwanda"
    })

    events.append({
        "timestamp": "2026-11-21T16:00:00",
        "subscriber_id": "SUB_ORDER",
        "event_type": "auth_request",
        "country": "Rwanda"
    })    

    return events


# ============================================================
# 4. SCHEMA / CONFORMANCE DETECTOR
# ============================================================


def detect_schema_anomalies(events):

    flagged = []

    required_fields = {
        "timestamp",
        "subscriber_id",
        "event_type",
        "country"
    }

    last_timestamp = {}

    for event in events:

        missing = required_fields - event.keys()

        if missing:

            flagged.append({
                "event": event,
                "rule": "SCHEMA_ERROR",
                "reason": (
                    "Missing required fields: "
                    + ", ".join(sorted(missing))
                )
            })

            continue

        if event["event_type"] not in ALLOWED_EVENT_TYPES:

            flagged.append({
                "event": event,
                "rule": "INVALID_EVENT_TYPE",
                "reason": (
                    "Unsupported event type: "
                    + str(event["event_type"])
                )
            })

        try:
            current_time = datetime.fromisoformat(
                event["timestamp"]
            )

        except (ValueError, TypeError):

            flagged.append({
                "event": event,
                "rule": "INVALID_TIMESTAMP",
                "reason": "Timestamp format is invalid."
            })

            continue

        subscriber = event["subscriber_id"]

        if (
            subscriber in last_timestamp
            and current_time < last_timestamp[subscriber]
        ):

            flagged.append({
                "event": event,
                "rule": "NON_MONOTONIC_TIMESTAMP",
                "reason": (
                    f"Subscriber {subscriber} has an event "
                    "with a timestamp earlier than the "
                    "previous event."
                )
            })

        last_timestamp[subscriber] = current_time

    return flagged



# ============================================================
# 5. IMPLAUSIBLE TRAVEL DETECTOR
# ============================================================


def detect_implausible_travel(events):

    flagged = []

    subscriber_events = defaultdict(list)

    required = {
        "timestamp",
        "subscriber_id",
        "event_type",
        "country"
    }

    # Group valid events by subscriber.
    for event in events:

        if not required.issubset(event.keys()):
            continue

        if event["event_type"] not in ALLOWED_EVENT_TYPES:
            continue

        try:
            timestamp = datetime.fromisoformat(
                event["timestamp"]
            )

        except (ValueError, TypeError):
            continue

        subscriber_events[event["subscriber_id"]].append(
            (timestamp, event)
        )

    # Check country changes for each subscriber.
    for subscriber, records in subscriber_events.items():

        records.sort(key=lambda item: item[0])

        for i in range(1, len(records)):

            previous_time, previous_event = records[i - 1]
            current_time, current_event = records[i]

            time_difference = (
                current_time - previous_time
            ).total_seconds() / 3600

            previous_country = previous_event["country"]
            current_country = current_event["country"]

            # Only investigate changes between different countries.
            if previous_country == current_country:
                continue

            route = (previous_country, current_country)

            # Use a route-specific threshold when available.
            minimum_time = MIN_TRAVEL_TIME_BY_ROUTE.get(
                route,
                MIN_TRAVEL_TIME_HOURS
            )

            if time_difference < minimum_time:

                flagged.append({
                    "event": current_event,
                    "rule": "IMPLAUSIBLE_TRAVEL",
                    "reason": (
                        f"Subscriber {subscriber} changed from "
                        f"{previous_country} to {current_country} "
                        f"in {time_difference:.2f} hours. "
                        f"Minimum expected time for this route: "
                        f"{minimum_time:.2f} hours."
                    )
                })

    return flagged



# ============================================================
# 6. AUTHENTICATION REQUEST BURST DETECTOR
# ============================================================

def detect_authentication_bursts(events):

    flagged = []

    subscriber_events = defaultdict(list)

    for event in events:

        if (
            event.get("event_type") == "auth_request"
            and "subscriber_id" in event
            and "timestamp" in event
        ):

            try:
                timestamp = datetime.fromisoformat(
                    event["timestamp"]
                )

            except (ValueError, TypeError):
                continue

            subscriber_events[event["subscriber_id"]].append(
                (timestamp, event)
            )

    for subscriber, records in subscriber_events.items():

        records.sort(key=lambda item: item[0])

        for i in range(len(records)):

            window_end = records[i][0] + timedelta(
                minutes=AUTH_WINDOW_MINUTES
            )

            window_records = [
                record for record in records[i:]
                if record[0] <= window_end
            ]

            if len(window_records) > MAX_AUTH_REQUESTS:

                flagged.append({
                    "event": window_records[-1][1],
                    "rule": "AUTH_REQUEST_BURST",
                    "reason": (
                        f"Subscriber {subscriber} generated "
                        f"{len(window_records)} authentication "
                        f"requests within "
                        f"{AUTH_WINDOW_MINUTES} minutes."
                    )
                })

                break

    return flagged

# ============================================================
# 7. ATTACHMENT REQUEST BURST DETECTOR
# ============================================================

def detect_attachment_request_bursts(events):

    flagged = []

    subscriber_events = defaultdict(list)

    for event in events:

        if (
            event.get("event_type") == "attach"
            and "subscriber_id" in event
            and "timestamp" in event
        ):

            try:
                timestamp = datetime.fromisoformat(
                    event["timestamp"]
                )

            except (ValueError, TypeError):
                continue

            subscriber_events[event["subscriber_id"]].append(
                (timestamp, event)
            )

    for subscriber, records in subscriber_events.items():

        records.sort(key=lambda item: item[0])

        for i in range(len(records)):

            window_end = records[i][0] + timedelta(
                minutes=ATTACH_WINDOW_MINUTES
            )

            window_records = [
                record for record in records[i:]
                if record[0] <= window_end
            ]

            if len(window_records) > MAX_ATTACH_REQUESTS:

                # Flag every request in the detected burst.
                for timestamp, event in window_records:

                    flagged.append({
                        "event": event,
                        "rule": "ATTACH_REQUEST_BURST",
                        "reason": (
                            f"Subscriber {subscriber} generated "
                            f"{len(window_records)} attachment "
                            f"requests within "
                            f"{ATTACH_WINDOW_MINUTES} minute."
                        )
                    })

                break

    return flagged


# ============================================================
# 7. MAIN INTRUSION DETECTION SYSTEM
# ============================================================

def main():

    print("=" * 70)
    print("TELECOM SIGNALING-PLANE ANOMALY DETECTION SYSTEM")
    print("=" * 70)

    # Generate normal events.
    events = generate_signaling_log(20)

    # Inject controlled suspicious events.
    events = inject_anomalies(events)

    print("\nTotal signaling events:", len(events))

    # Run all detection rules.
    schema_results = detect_schema_anomalies(events)

    travel_results = detect_implausible_travel(events)

    burst_results = detect_authentication_bursts(events)
    attach_results = detect_attachment_request_bursts(events)

    all_results = (
        schema_results
        + travel_results
        + burst_results
        + attach_results
    )

    # Display detection results.
    print("\n" + "=" * 70)
    print("DETECTION RESULTS")
    print("=" * 70)

    if not all_results:

        print("No anomalies detected.")

    else:

        for number, result in enumerate(all_results, start=1):

            event = result["event"]

            print(f"\nANOMALY #{number}")

            print("Rule:", result["rule"])

            print(
                "Subscriber:",
                event.get("subscriber_id", "UNKNOWN")
            )

            print(
                "Timestamp:",
                event.get("timestamp", "UNKNOWN")
            )

            print("Reason:", result["reason"])

    # Final summary.
    print("\n" + "=" * 70)
    print("ANOMALY DETECTION SUMMARY")
    print("=" * 70)

    print("Total events:", len(events))

    print("Schema anomalies:", len(schema_results))

    print("Implausible travel anomalies:", len(travel_results))

    print("Authentication bursts:", len(burst_results))
    print("Attachment request bursts:", len(attach_results))

    print("Total detection alerts:", len(all_results))

    print("\nSIMULATION COMPLETED.")


if __name__ == "__main__":

    random.seed(42)

    main()
