
import sys
from pathlib import Path
from datetime import datetime, timedelta

# ============================================================
# 1. IMPORT THE ACTUAL PART B DETECTION FUNCTIONS
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from part_b_anomaly_detection.signaling_ids import (
    detect_schema_anomalies,
    detect_implausible_travel,
    detect_authentication_bursts,
    detect_attachment_request_bursts
)

# ============================================================
# 2. GENERATE A LABELED EVALUATION DATASET
# ============================================================

def create_evaluation_dataset():

    events = []
    ground_truth = {}

    base_time = datetime(2026, 11, 21, 8, 0, 0)

    # --------------------------------------------------------
    # A. NORMAL SIGNALING EVENTS
    # --------------------------------------------------------

    subscribers = {
        "NORMAL001": "Rwanda",
        "NORMAL002": "Kenya",
        "NORMAL003": "Uganda",
        "NORMAL004": "Tanzania",
        "NORMAL005": "Rwanda"
    }

    event_types = [
        "attach",
        "location_update",
        "auth_request"
    ]

    for i in range(25):

        subscriber = list(subscribers.keys())[i % 5]

        event = {
            "event_id": f"NORMAL_{i + 1}",
            "timestamp": (
                base_time + timedelta(minutes=i * 3)
            ).isoformat(),
            "subscriber_id": subscriber,
            "event_type": event_types[i % 3],
            "country": subscribers[subscriber]
        }

        events.append(event)
        ground_truth[event["event_id"]] = 0

    # --------------------------------------------------------
    # B. ATTACK 1: MISSING REQUIRED FIELD
    # --------------------------------------------------------

    events.append({
        "event_id": "ATTACK_MISSING_FIELD",
        "timestamp": "2026-11-21T10:00:00",
        "subscriber_id": "ATTACK_SCHEMA",
        "event_type": "attach"
    })

    ground_truth["ATTACK_MISSING_FIELD"] = 1

    # --------------------------------------------------------
    # C. ATTACK 2: INVALID EVENT TYPE
    # --------------------------------------------------------

    events.append({
        "event_id": "ATTACK_INVALID_TYPE",
        "timestamp": "2026-11-21T10:10:00",
        "subscriber_id": "ATTACK_INVALID",
        "event_type": "unknown_event",
        "country": "Rwanda"
    })

    ground_truth["ATTACK_INVALID_TYPE"] = 1

    # --------------------------------------------------------
    # D. ATTACK 3: NON-MONOTONIC TIMESTAMP
    # --------------------------------------------------------

    events.append({
        "event_id": "ORDER_FIRST",
        "timestamp": "2026-11-21T11:10:00",
        "subscriber_id": "ATTACK_ORDER",
        "event_type": "location_update",
        "country": "Rwanda"
    })

    ground_truth["ORDER_FIRST"] = 0

    events.append({
        "event_id": "ATTACK_NON_MONOTONIC",
        "timestamp": "2026-11-21T11:00:00",
        "subscriber_id": "ATTACK_ORDER",
        "event_type": "auth_request",
        "country": "Rwanda"
    })

    ground_truth["ATTACK_NON_MONOTONIC"] = 1

    # --------------------------------------------------------
    # E. ATTACK 4: IMPLAUSIBLE INTERNATIONAL TRAVEL
    # --------------------------------------------------------

    events.append({
        "event_id": "TRAVEL_FIRST",
        "timestamp": "2026-11-21T12:00:00",
        "subscriber_id": "ATTACK_TRAVEL",
        "event_type": "location_update",
        "country": "Rwanda"
    })

    ground_truth["TRAVEL_FIRST"] = 0

    events.append({
        "event_id": "ATTACK_IMPLAUSIBLE_TRAVEL",
        "timestamp": "2026-11-21T12:20:00",
        "subscriber_id": "ATTACK_TRAVEL",
        "event_type": "location_update",
        "country": "United Kingdom"
    })

    ground_truth["ATTACK_IMPLAUSIBLE_TRAVEL"] = 1

    # --------------------------------------------------------
    # F. ATTACK 5: AUTHENTICATION REQUEST BURST
    # --------------------------------------------------------

    for i in range(6):

        event_id = f"BURST_{i + 1}"

        events.append({
            "event_id": event_id,
            "timestamp": (
                datetime(2026, 11, 21, 13, 0, 0)
                + timedelta(seconds=i * 30)
            ).isoformat(),
            "subscriber_id": "ATTACK_BURST",
            "event_type": "auth_request",
            "country": "Rwanda"
        })

        # The final request is the event that triggers
        # the detector's burst alert.
        ground_truth[event_id] = 1 if i == 5 else 0

    # --------------------------------------------------------
    # G. BENIGN ROAMING: FALSE-POSITIVE TEST
    # --------------------------------------------------------

    events.append({
        "event_id": "ROAMING_FIRST",
        "timestamp": "2026-11-21T14:00:00",
        "subscriber_id": "BENIGN_ROAMING",
        "event_type": "location_update",
        "country": "Rwanda"
    })

    ground_truth["ROAMING_FIRST"] = 0

    events.append({
        "event_id": "BENIGN_ROAMING_EVENT",
        "timestamp": "2026-11-21T15:00:00",
        "subscriber_id": "BENIGN_ROAMING",
        "event_type": "location_update",
        "country": "Uganda"
    })

    # For this controlled experiment, this represents
    # legitimate roaming despite the short time interval.
    ground_truth["BENIGN_ROAMING_EVENT"] = 0

    # --------------------------------------------------------
    # H. UNSUPPORTED ATTACK: FALSE-NEGATIVE TEST
    # --------------------------------------------------------

    # A signaling attach flood is injected.
    # The current detector has no attach-flood rule.

    for i in range(6):

        event_id = f"ATTACH_FLOOD_{i + 1}"

        events.append({
            "event_id": event_id,
            "timestamp": (
                datetime(2026, 11, 21, 16, 0, 0)
                + timedelta(seconds=i * 10)
            ).isoformat(),
            "subscriber_id": "ATTACK_ATTACH_FLOOD",
            "event_type": "attach",
            "country": "Rwanda"
        })

        ground_truth[event_id] = 1

    return events, ground_truth


# ============================================================
# 3. RUN THE EXISTING DETECTION SYSTEM
# ============================================================

def run_detection(events):

    results = []

    results.extend(detect_schema_anomalies(events))
    results.extend(detect_implausible_travel(events))
    results.extend(detect_authentication_bursts(events))
    results.extend(detect_attachment_request_bursts(events))

    detected_ids = set()

    for result in results:

        event = result["event"]

        event_id = event.get("event_id")

        if event_id:
            detected_ids.add(event_id)

    return results, detected_ids


# ============================================================
# 4. CALCULATE PERFORMANCE METRICS
# ============================================================

def calculate_metrics(ground_truth, detected_ids):

    true_positive = 0
    false_positive = 0
    true_negative = 0
    false_negative = 0

    for event_id, actual in ground_truth.items():

        predicted = int(event_id in detected_ids)

        if actual == 1 and predicted == 1:
            true_positive += 1

        elif actual == 0 and predicted == 1:
            false_positive += 1

        elif actual == 0 and predicted == 0:
            true_negative += 1

        elif actual == 1 and predicted == 0:
            false_negative += 1

    total = len(ground_truth)

    accuracy = (
        (true_positive + true_negative) / total
        if total else 0
    )

    precision = (
        true_positive / (true_positive + false_positive)
        if (true_positive + false_positive) else 0
    )

    recall = (
        true_positive / (true_positive + false_negative)
        if (true_positive + false_negative) else 0
    )

    f1_score = (
        2 * precision * recall / (precision + recall)
        if (precision + recall) else 0
    )

    specificity = (
        true_negative / (true_negative + false_positive)
        if (true_negative + false_positive) else 0
    )

    return {
        "TP": true_positive,
        "FP": false_positive,
        "TN": true_negative,
        "FN": false_negative,
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "specificity": specificity,
        "f1_score": f1_score
    }


# ============================================================
# 5. DISPLAY EVALUATION RESULTS
# ============================================================

def main():

    print("=" * 70)
    print("TELECOM ANOMALY DETECTION PERFORMANCE EVALUATION")
    print("=" * 70)

    events, ground_truth = create_evaluation_dataset()

    results, detected_ids = run_detection(events)

    metrics = calculate_metrics(
        ground_truth,
        detected_ids
    )

    print("\nDATASET INFORMATION")
    print("-" * 70)

    print("Total signaling events:", len(events))
    print("Actual anomaly events:", sum(ground_truth.values()))
    print("Actual normal events:", len(ground_truth) - sum(ground_truth.values()))
    print("Detection alerts:", len(results))

    print("\nDETECTION ALERTS")
    print("-" * 70)

    for result in results:

        event = result["event"]

        print(
            f"{result['rule']:<28} "
            f"{event.get('event_id', 'UNKNOWN')}"
        )

    print("\nCONFUSION MATRIX")
    print("-" * 70)

    print(f"True Positives  (TP): {metrics['TP']}")
    print(f"False Positives (FP): {metrics['FP']}")
    print(f"True Negatives  (TN): {metrics['TN']}")
    print(f"False Negatives (FN): {metrics['FN']}")

    print("\nPERFORMANCE METRICS")
    print("-" * 70)

    print(f"Accuracy:     {metrics['accuracy']:.4f}")
    print(f"Precision:    {metrics['precision']:.4f}")
    print(f"Recall:       {metrics['recall']:.4f}")
    print(f"Specificity:  {metrics['specificity']:.4f}")
    print(f"F1-score:     {metrics['f1_score']:.4f}")

    print("\nMISSED ANOMALIES")
    print("-" * 70)

    missed = [
        event_id
        for event_id, actual in ground_truth.items()
        if actual == 1 and event_id not in detected_ids
    ]

    if missed:

        for event_id in missed:
            print(event_id)

    else:
        print("No missed anomalies.")

    print("\nFALSE POSITIVE EVENTS")
    print("-" * 70)

    false_alarms = [
        event_id
        for event_id, actual in ground_truth.items()
        if actual == 0 and event_id in detected_ids
    ]

    if false_alarms:

        for event_id in false_alarms:
            print(event_id)

    else:
        print("No false positives.")

    print("\n" + "=" * 70)
    print("EVALUATION COMPLETED")
    print("=" * 70)


if __name__ == "__main__":
    main()
